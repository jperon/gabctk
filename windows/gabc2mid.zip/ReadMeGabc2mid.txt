Wednesday, June 26, 2013
gabc2mid.exe
by Father Jacques Peron
https://github.com/jperon/gabc2mid

This little applicaion will create a midi file from a gabc score.

-------------------------------------------------------------------
DESCRIPTION
gabc is the language used by the program called Gregorio, an application designed to render code as Gregorian Chant.

Gregorio Home page: http://home.gna.org/gregorio/
Description of gabc: http://home.gna.org/gregorio/gabc/

This application extracts the code from the gabc file, reads the melody and produces a midi file from the results.

For more information, please see the accompanying gabc2mid.chm help file.

-------------------------------------------------------------------
LICENSE:
By using this program you thereby agree to the terms of this license agreement.  You use this application at your own risk, and assume the entire responsibility of it use - that means that if it does something dastardly to your computer, it is your own fault.  However, to reassure you, know that the authour has tested it and uses it himself.

This application may be used for any use private or commercial, and without any fees.  You may distribute it however you like as long as you don't charge for it, and as long as it remains unchanged, and is accompanied by this help file.

-------------------------------------------------------------------
CONTACT:
If you have ideas for improvements, or want to report a bug, please use the github interface:
https://github.com/jperon/gabc2mid/issues
or you may post something to the gregorio mailing list:
https://mail.gna.org/listinfo/gregorio-users